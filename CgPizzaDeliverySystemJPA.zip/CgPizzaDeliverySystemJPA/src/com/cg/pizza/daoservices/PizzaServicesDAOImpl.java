package com.cg.pizza.daoservices;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.util.PizzaDBUtil;

public class PizzaServicesDAOImpl implements PizzaDAO
{
	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Customer save(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public Customer findOne(int custId) {
		return entityManagerFactory.createEntityManager().find(Customer.class,custId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> findAll() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("from Customer a",Customer.class);
		return query.getResultList();
	}

}

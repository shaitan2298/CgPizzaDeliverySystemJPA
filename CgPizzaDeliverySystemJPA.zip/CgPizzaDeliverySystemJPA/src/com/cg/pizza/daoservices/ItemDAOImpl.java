package com.cg.pizza.daoservices;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Items;

public class ItemDAOImpl implements ItemDAO
{
	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Items save(Items item) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(item);
		entityManager.getTransaction().commit();
		entityManager.close();
		return item;
	}

	@Override
	public Items getItemPrice(int itemId) {
		return entityManagerFactory.createEntityManager().find(Items.class, itemId);
	}

}

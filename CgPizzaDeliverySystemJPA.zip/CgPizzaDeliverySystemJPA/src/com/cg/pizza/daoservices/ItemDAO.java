package com.cg.pizza.daoservices;

import com.cg.pizza.beans.Items;

public interface ItemDAO {
	Items save(Items item);
	Items getItemPrice(int itemId);
}
